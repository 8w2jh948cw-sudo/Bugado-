importScripts('./config/app-meta.js');

// v0.7.1: refinamentos de ícones, animações e controles de Ajustes.
const CACHE=`cronometro-${APP_META.version}`;
const ASSETS=[
  './',
  './index.html',
  './manifest.webmanifest',
  './icon.svg',
  './config/app-meta.js',
  './config/ui-config.js',
  './data/initial-data.json',
  './css/base.css',
  './css/components.css',
  './css/pages.css',
  './js/state.js',
  './js/database.js',
  './js/timers.js',
  './js/models.js',
  './js/records.js',
  './js/theme.js',
  './js/render.js',
  './js/export.js',
  './js/events.js',
  './js/app.js'
];

self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));
});

self.addEventListener('activate',event=>{
  event.waitUntil(Promise.all([
    caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('cronometro-')&&key!==CACHE).map(key=>caches.delete(key)))),
    self.clients.claim()
  ]));
});

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  event.respondWith(
    fetch(event.request).then(response=>{
      const copy=response.clone();
      caches.open(CACHE).then(cache=>cache.put(event.request,copy));
      return response;
    }).catch(()=>caches.match(event.request).then(hit=>hit||caches.match('./index.html')))
  );
});
