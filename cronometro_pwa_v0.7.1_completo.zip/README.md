# Cronômetro PWA — v0.7.1

Versão consolidada do aplicativo de cronometragem para iPhone/PWA.

## Principais mudanças da v0.7.1

- Novo seletor **Pequeno / Grande** para os cronômetros.
- Ícones dos cronômetros passam a ser fixos por estado, usando Lucide:
  - normal: `play`;
  - ativo: `disc-3`;
  - usado/pausado: `pause`.
- O `disc-3` ativo pode girar em três velocidades: Lenta, Normal e Rápida; a animação pode ser desligada em Ajustes.
- O contador do cronômetro ativo usa a cor de ação do tema.
- O Tempo total fica colorido quando há cronômetro rodando e apenas os `:` piscam; o piscar pode ser desligado.
- Tempo total + Salvar formam um grupo flutuante 50/50; cada cartão continua independente visualmente.
- Barra de abas é flutuante, sem rodapé, sem textos, com ícones maiores e visual translúcido.
- Ajustes reorganizados: Tema, Backup, Dados e exportação, Armazenamento e novas opções de animação.
- Removida a escolha de símbolo/ícone ao criar ou editar cronômetros.
- Tema escuro usa equivalentes iOS para as cores de destaque dos temas predefinidos.

## Estrutura

- `config/` — versão e configuração visual.
- `data/` — dados iniciais de fábrica.
- `css/` — aparência.
- `js/` — funcionamento por responsabilidade.
- `THIRD_PARTY_NOTICES.txt` — atribuição dos ícones Lucide utilizados.

## Dados

O banco principal continua sendo IndexedDB. Atualizar os arquivos do projeto não apaga os registros do usuário.

Em instalação nova, o modelo **Manutenção** com 10 cronômetros é criado uma única vez. Depois disso ele vira dado normal e pode ser alterado ou apagado sem ser recriado automaticamente.
