'use strict';
globalThis.APP_META = Object.freeze({
  version: '0.7.1',
  dataSchemaVersion: 3,
  factoryDataVersion: 1
});
