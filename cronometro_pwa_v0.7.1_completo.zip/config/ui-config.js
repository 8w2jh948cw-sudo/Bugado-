'use strict';

globalThis.UI_CONFIG = Object.freeze({
  colors: {
    light: {
      bg: '#F2F2F6', card: '#FFFFFF', text: '#000000', secondary: '#85858A',
      line: '#E7E7E8', placeholder: '#C5C5C7', glass: 'rgba(255,255,255,.62)',
      floatBorder: 'rgba(255,255,255,.92)', usedText: '#F2F2F6'
    },
    dark: {
      bg: '#000000', card: '#1C1C1E', text: '#FFFFFF', secondary: '#98989D',
      line: '#38383A', placeholder: '#636366', glass: 'rgba(44,44,46,.72)',
      floatBorder: 'rgba(255,255,255,.12)', usedText: '#3A3A3C'
    },
    deleteFixed: '#E22400'
  },

  sizes: {
    contentSide:18, contentTop:14, topbarHeight:54, headerButton:40, headerIcon:22,
    titleSize:17.5, topTabTitleSize:20,

    settingsRadius:30, settingsRowHeight:56, settingsSide:18, settingsPadX:18,

    historyRadius:20, historyPadY:14, historyPadX:16, historyTitleSize:16,
    historyFilterHeight:44, historyFilterRadius:14,

    panelRadius:24, modalRadius:52, sheetCardRadius:30,
    borderWidth:1, iconStroke:1.8
  },

  header: {
    circleBorderWidth:0.75,
    circleBorderLight:'#FFFFFF',
    circleBorderDark:'#474747',
    iconStroke:2.3
  },

  timerModes: {
    small: {
      name:'Pequeno', layout:'lateral',
      minHeight:64, radius:30, padY:11, padX:14, gap:10, listGap:9,
      iconBox:38, iconRadius:13, iconSize:21, iconStroke:1.8,
      nameSize:13, nameWeight:620, nameAlignH:'left', nameAlignV:'center',
      timeSize:24, timeWeight:780, timeAlignH:'right', timeAlignV:'center',
      borderWidth:0, borderLight:'#FFFFFF', borderDark:'#38383A',
      shadow:{enabled:true,x:0,y:8,blur:24,spread:0,opacity:0.02},
      addHeight:52, addTextSize:14.5, addTextWeight:620, addIconStroke:2.5
    },
    large: {
      name:'Grande', layout:'central',
      minHeight:60, radius:40, padY:11, padX:14, gap:0, listGap:11,
      iconBox:38, iconRadius:13, iconSize:21, iconStroke:1.8,
      nameSize:18, nameWeight:620, nameAlignH:'center', nameAlignV:'top',
      timeSize:80, timeWeight:700, timeAlignH:'center', timeAlignV:'top',
      borderWidth:0, borderLight:'#FFFFFF', borderDark:'#38383A',
      shadow:{enabled:false,x:0,y:8,blur:24,spread:0,opacity:0.06},
      addHeight:52, addTextSize:14.5, addTextWeight:620, addIconStroke:2.5
    }
  },

  actionGroup: {
    side:18, bottom:82, height:60, gap:10, totalFraction:1, saveFraction:1
  },

  totalCard: {
    radius:20, borderWidth:1, blur:16,
    shadow:{x:0,y:12,blur:25,spread:0,opacity:0.155},
    labelSize:12, labelWeight:500, timeSize:30, timeWeight:700,
    iconBox:32, iconSize:28, iconStroke:2.35,
    light:{bg:'#FFFFFF',text:'#000000',secondary:'#85858A',border:'#FFFFFF',iconBg:'#EAF3FF'},
    dark:{bg:'#1C1C1E',text:'#FFFFFF',secondary:'#98989D',border:'#38383A',iconBg:'#172A40'}
  },

  saveCard: {
    radius:20, borderWidth:1, blur:0,
    shadow:{x:0,y:12,blur:25,spread:0,opacity:0.155},
    textSize:20, textWeight:700, iconSize:25, iconStroke:4, gap:7
  },

  tabbar: {
    light:{background:'#F2F2F2',border:'#FFFFFF',icon:'#333333',selectedBackground:'#EBEBEB'},
    dark:{background:'#1C1C1E',border:'#474747',icon:'#C2C2C2',selectedBackground:'#3A3A3C'},
    opacity:0.53, left:14, right:14, bottom:18, height:50, padding:1.5, gap:6,
    radius:999, borderWidth:0.75, blur:7,
    shadow:{x:0,y:12,blur:34,spread:0,opacity:0.19},
    shadow2:{x:0,y:2,blur:10,spread:0,opacity:0.185},
    iconSize:35, iconStroke:1.5, showLabels:false
  },

  animationSpeeds: {
    slow:{id:'slow',name:'Lenta',durationMs:2400},
    normal:{id:'normal',name:'Normal',durationMs:1400},
    fast:{id:'fast',name:'Rápida',durationMs:800}
  },

  themePresets: [
    {id:'original',name:'Padrão',accent:'#007AFF',action:'#34C759',darkAccent:'#0A84FF',darkAction:'#30D158',saveBorderLight:'#56CF74'},
    {id:'blue',name:'Azul',accent:'#007AFF',action:'#007AFF',darkAccent:'#0A84FF',darkAction:'#0A84FF'},
    {id:'green',name:'Verde',accent:'#34C759',action:'#34C759',darkAccent:'#30D158',darkAction:'#30D158'},
    {id:'purple',name:'Roxo',accent:'#AF52DE',action:'#AF52DE',darkAccent:'#BF5AF2',darkAction:'#BF5AF2'},
    {id:'pink',name:'Rosa',accent:'#FF2D55',action:'#FF2D55',darkAccent:'#FF375F',darkAction:'#FF375F'},
    {id:'orange',name:'Laranja',accent:'#FF9500',action:'#FF9500',darkAccent:'#FF9F0A',darkAction:'#FF9F0A'},
    {id:'indigo',name:'Índigo',accent:'#5856D6',action:'#5856D6',darkAccent:'#5E5CE6',darkAction:'#5E5CE6'}
  ]
});
