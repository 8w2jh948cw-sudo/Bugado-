'use strict';

async function init(){
  db=await openDB();

  // Dados de fábrica entram no mesmo banco realmente usado pelo app.
  await seedFactoryDataIfNeeded();

  data.models=await getAll('models');
  data.sessions=await getAll('sessions');
  data.settings={...data.settings,...(await getState('settings')||{}),simultaneous:'single'};
  data.current=await getState('current');

  // Migração da preferência criada nas versões 0.5.x.
  if(localStorage.getItem('show_version_badge')==='1'&&!data.settings.showVersionBadge){
    data.settings.showVersionBadge=true;
    await persistSettings();
  }

  if(!(UI_CONFIG.themePresets||[]).some(p=>p.id===data.settings.colorTheme)){
    data.settings.colorTheme='original';
    await persistSettings();
  }

  let settingsChanged=false;
  if(!UI_CONFIG.timerModes?.[data.settings.timerSize]){data.settings.timerSize='small';settingsChanged=true;}
  if(!UI_CONFIG.animationSpeeds?.[data.settings.activeTimerAnimationSpeed]){data.settings.activeTimerAnimationSpeed='normal';settingsChanged=true;}
  if(typeof data.settings.animateActiveTimerIcon!=='boolean'){data.settings.animateActiveTimerIcon=true;settingsChanged=true;}
  if(typeof data.settings.blinkTotalColon!=='boolean'){data.settings.blinkTotalColon=true;settingsChanged=true;}
  if(settingsChanged)await persistSettings();

  let modelOrderChanged=false;
  activeModels().forEach((m,i)=>{
    if(!Number.isFinite(m.sortOrder)){
      m.sortOrder=i;
      modelOrderChanged=true;
    }
  });
  if(modelOrderChanged){
    for(const m of data.models)await put('models',m);
  }

  if(data.current?.globalPaused){
    data.current.globalPaused=false;
    data.current.pausedActiveTimerIds=[];
    await persistCurrent();
  }

  if(data.current?.status!=='active')data.current=null;

  if(!data.current){
    const model=activeModels()[0];
    if(model){
      data.current=newSession(model);
      await persistCurrent();
    }
  }

  await purgeExpired();
  render();

  tickHandle=setInterval(()=>{
    if(ui.tab==='timers'&&ui.timerView==='timers'&&data.current&&data.current.timers.some(isTimerActive))refreshTimerReadouts();
  },1000);

  if('serviceWorker' in navigator){
    try{await navigator.serviceWorker.register('./sw.js');}
    catch(error){console.warn('Service worker não registrado',error);}
  }

  document.addEventListener('visibilitychange',()=>{
    if(!document.hidden)render();
  });
}

init().catch(err=>{
  console.error(err);
  $app.innerHTML=`<main class="content"><h1>Erro ao abrir o aplicativo</h1><pre>${esc(err.message)}</pre></main>`;
});
