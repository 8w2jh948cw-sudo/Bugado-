'use strict';

function cssNum(v,fallback=0){const n=Number(v);return Number.isFinite(n)?n:fallback;}
function clamp01(v){return Math.max(0,Math.min(1,Number(v)||0));}
function colorWithAlpha(color,opacity){
  const a=clamp01(opacity);
  const m=String(color||'').match(/^#([0-9a-f]{6})$/i);
  if(!m)return `color-mix(in srgb,${color} ${a*100}%,transparent)`;
  const n=parseInt(m[1],16);
  return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`;
}
function currentPreset(){
  const presets=UI_CONFIG.themePresets||[];
  return presets.find(p=>p.id===data.settings.colorTheme)||presets[0]||{accent:'#007AFF',action:'#34C759',darkAccent:'#0A84FF',darkAction:'#30D158'};
}
function currentTimerMode(){
  return UI_CONFIG.timerModes?.[data.settings.timerSize]||UI_CONFIG.timerModes?.small||{};
}
function shadowCss(sh={}){
  return `${cssNum(sh.x)}px ${cssNum(sh.y)}px ${cssNum(sh.blur)}px ${cssNum(sh.spread)}px rgba(0,0,0,${clamp01(sh.opacity)})`;
}
function cssVerticalAlign(v){return v==='top'?'start':v==='bottom'?'end':'center';}
function activeTimerAnimationDuration(){
  const speed=UI_CONFIG.animationSpeeds?.[data.settings.activeTimerAnimationSpeed]||UI_CONFIG.animationSpeeds?.normal;
  return cssNum(speed?.durationMs,1400);
}
function applyTheme(){
  const root=document.documentElement;
  if(data.settings.theme==='system')root.removeAttribute('data-theme');
  else root.setAttribute('data-theme',data.settings.theme);

  const c=UI_CONFIG.colors||{},z=UI_CONFIG.sizes||{},h=UI_CONFIG.header||{},m=currentTimerMode();
  const ag=UI_CONFIG.actionGroup||{},total=UI_CONFIG.totalCard||{},save=UI_CONFIG.saveCard||{},tab=UI_CONFIG.tabbar||{};
  const custom=data.settings.colorTheme==='custom';
  const preset=currentPreset();
  const accentLight=custom?(data.settings.accentColor||'#007AFF'):(preset.accent||'#007AFF');
  const actionLight=custom?accentLight:(preset.action||accentLight);
  const accentDark=custom?accentLight:(preset.darkAccent||preset.accent||'#0A84FF');
  const actionDark=custom?accentDark:(preset.darkAction||preset.action||accentDark);

  const vars={
    '--accent-light':accentLight,'--action-light':actionLight,
    '--accent-dark':accentDark,'--action-dark':actionDark,
    '--switch-on':actionLight,
    '--save-border-light':custom?actionLight:(preset.saveBorderLight||actionLight),'--save-border-dark':actionDark,
    '--delete-fixed':c.deleteFixed||'#E22400',

    '--light-bg':c.light?.bg,'--light-card':c.light?.card,'--light-text':c.light?.text,
    '--light-secondary':c.light?.secondary,'--light-line':c.light?.line,
    '--light-placeholder':c.light?.placeholder,'--light-glass':c.light?.glass,
    '--light-float-border':c.light?.floatBorder,'--light-used':c.light?.usedText,

    '--dark-bg':c.dark?.bg,'--dark-card':c.dark?.card,'--dark-text':c.dark?.text,
    '--dark-secondary':c.dark?.secondary,'--dark-line':c.dark?.line,
    '--dark-placeholder':c.dark?.placeholder,'--dark-glass':c.dark?.glass,
    '--dark-float-border':c.dark?.floatBorder,'--dark-used':c.dark?.usedText,

    '--content-side':`${cssNum(z.contentSide,18)}px`,'--content-top':`${cssNum(z.contentTop,14)}px`,
    '--topbar-height':`${cssNum(z.topbarHeight,54)}px`,'--header-button':`${cssNum(z.headerButton,40)}px`,
    '--header-icon':`${cssNum(z.headerIcon,22)}px`,'--title-size':`${cssNum(z.titleSize,17.5)}px`,
    '--header-circle-border':`${cssNum(h.circleBorderWidth,.75)}px`,
    '--light-header-circle-border':h.circleBorderLight||'#FFFFFF','--dark-header-circle-border':h.circleBorderDark||'#474747',
    '--header-icon-stroke':cssNum(h.iconStroke,2.3),

    '--timer-min-height':`${cssNum(m.minHeight,64)}px`,'--timer-radius':`${cssNum(m.radius,30)}px`,
    '--timer-pad-y':`${cssNum(m.padY,11)}px`,'--timer-pad-x':`${cssNum(m.padX,14)}px`,
    '--timer-gap':`${cssNum(m.gap,10)}px`,'--timer-list-gap':`${cssNum(m.listGap,9)}px`,
    '--timer-icon-size':`${cssNum(m.iconBox,38)}px`,'--timer-icon-radius':`${cssNum(m.iconRadius,13)}px`,
    '--timer-icon-inner':`${cssNum(m.iconSize,21)}px`,'--timer-icon-stroke':cssNum(m.iconStroke,1.8),
    '--timer-name-size':`${cssNum(m.nameSize,15)}px`,'--timer-name-weight':cssNum(m.nameWeight,620),
    '--timer-time-size':`${cssNum(m.timeSize,24)}px`,'--timer-time-weight':cssNum(m.timeWeight,780),
    '--timer-name-align':m.nameAlignH||'left','--timer-time-align':m.timeAlignH||'right',
    '--timer-name-v-align':cssVerticalAlign(m.nameAlignV),'--timer-time-v-align':cssVerticalAlign(m.timeAlignV),
    '--timer-border-width':`${cssNum(m.borderWidth)}px`,'--light-timer-border':m.borderLight||'#FFFFFF','--dark-timer-border':m.borderDark||'#38383A',
    '--timer-card-shadow':m.shadow?.enabled?shadowCss(m.shadow):'none',
    '--add-height':`${cssNum(m.addHeight,52)}px`,'--add-text-size':`${cssNum(m.addTextSize,14.5)}px`,
    '--add-text-weight':cssNum(m.addTextWeight,620),'--add-icon-stroke':cssNum(m.addIconStroke,2.5),

    '--action-group-side':`${cssNum(ag.side,18)}px`,'--action-group-bottom':`${cssNum(ag.bottom,82)}px`,
    '--floating-height':`${cssNum(ag.height,60)}px`,'--floating-gap':`${cssNum(ag.gap,10)}px`,
    '--action-total-fr':cssNum(ag.totalFraction,1),'--action-save-fr':cssNum(ag.saveFraction,1),

    '--total-radius':`${cssNum(total.radius,20)}px`,'--total-border-width':`${cssNum(total.borderWidth,1)}px`,
    '--total-blur':`${cssNum(total.blur,16)}px`,'--total-shadow':shadowCss(total.shadow),
    '--total-label-size':`${cssNum(total.labelSize,12)}px`,'--total-label-weight':cssNum(total.labelWeight,500),
    '--total-time-size':`${cssNum(total.timeSize,30)}px`,'--total-time-weight':cssNum(total.timeWeight,700),
    '--total-icon-box':`${cssNum(total.iconBox,32)}px`,'--total-icon-size':`${cssNum(total.iconSize,28)}px`,'--total-icon-stroke':cssNum(total.iconStroke,2.35),
    '--light-total-bg':total.light?.bg,'--light-total-text':total.light?.text,'--light-total-secondary':total.light?.secondary,
    '--light-total-border':total.light?.border,'--light-total-icon-bg':total.light?.iconBg,
    '--dark-total-bg':total.dark?.bg,'--dark-total-text':total.dark?.text,'--dark-total-secondary':total.dark?.secondary,
    '--dark-total-border':total.dark?.border,'--dark-total-icon-bg':total.dark?.iconBg,

    '--save-radius':`${cssNum(save.radius,20)}px`,'--save-border-width':`${cssNum(save.borderWidth,1)}px`,
    '--save-blur':`${cssNum(save.blur)}px`,'--save-shadow':shadowCss(save.shadow),
    '--save-text-size':`${cssNum(save.textSize,20)}px`,'--save-text-weight':cssNum(save.textWeight,700),
    '--save-icon-size':`${cssNum(save.iconSize,25)}px`,'--save-icon-stroke':cssNum(save.iconStroke,4),'--save-gap':`${cssNum(save.gap,7)}px`,

    '--light-tabbar-bg':colorWithAlpha(tab.light?.background||'#F2F2F2',tab.opacity),'--light-tabbar-border':tab.light?.border,'--light-tabbar-icon':tab.light?.icon,
    '--light-tabbar-selected-bg':tab.light?.selectedBackground,
    '--dark-tabbar-bg':colorWithAlpha(tab.dark?.background||'#1C1C1E',tab.opacity),'--dark-tabbar-border':tab.dark?.border,'--dark-tabbar-icon':tab.dark?.icon,
    '--dark-tabbar-selected-bg':tab.dark?.selectedBackground,
    '--tabbar-opacity':clamp01(tab.opacity),'--tabbar-left':`${cssNum(tab.left,14)}px`,'--tabbar-right':`${cssNum(tab.right,14)}px`,
    '--tabbar-bottom':`${cssNum(tab.bottom,18)}px`,'--tabbar-height':`${cssNum(tab.height,50)}px`,
    '--tabbar-padding':`${cssNum(tab.padding,1.5)}px`,'--tabbar-gap':`${cssNum(tab.gap,6)}px`,'--tabbar-radius':`${cssNum(tab.radius,999)}px`,
    '--tabbar-border-width':`${cssNum(tab.borderWidth,.75)}px`,'--tabbar-blur':`${cssNum(tab.blur,7)}px`,
    '--tabbar-shadow':`${shadowCss(tab.shadow)}, ${shadowCss(tab.shadow2)}`,
    '--tab-icon':`${cssNum(tab.iconSize,35)}px`,'--tab-icon-stroke':cssNum(tab.iconStroke,1.5),

    '--settings-radius':`${cssNum(z.settingsRadius,30)}px`,'--settings-row-height':`${cssNum(z.settingsRowHeight,56)}px`,
    '--settings-side':`${cssNum(z.settingsSide,18)}px`,'--settings-pad-x':`${cssNum(z.settingsPadX,18)}px`,
    '--history-radius':`${cssNum(z.historyRadius,20)}px`,'--history-pad-y':`${cssNum(z.historyPadY,14)}px`,
    '--history-pad-x':`${cssNum(z.historyPadX,16)}px`,'--history-title-size':`${cssNum(z.historyTitleSize,16)}px`,
    '--panel-radius':`${cssNum(z.panelRadius,24)}px`,'--modal-radius':`${cssNum(z.modalRadius,52)}px`,
    '--sheet-card-radius':`${cssNum(z.sheetCardRadius,30)}px`,'--border-width':`${cssNum(z.borderWidth,1)}px`,
    '--icon-stroke':cssNum(z.iconStroke,1.8),

    '--active-disc-duration':`${activeTimerAnimationDuration()}ms`
  };

  for(const [key,value] of Object.entries(vars))if(value!=null)root.style.setProperty(key,value);
}
