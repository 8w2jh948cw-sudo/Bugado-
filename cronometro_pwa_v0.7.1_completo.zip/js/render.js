'use strict';

function currentTitle(){ const s=data.current; if(!s)return 'Cronômetro'; return s.manualTitle&&s.title?s.title:`(sem título) ${fmtDateTime(s.firstTimerStartedAt??s.openedAt)}`; }
function timerStateClass(s,rt){ if(isTimerActive(rt))return 'active'; if(isTimerPaused(s,rt))return 'paused'; return ''; }
function svgIcon(name){
  const icons={
    timers:'<circle cx="12" cy="13" r="7.5"/><path d="M12 13V8.7M9 2.5h6M16.7 5.2l1.4-1.4"/>',
    history:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/>',
    stats:'<path d="M3 3v18h18"/><path d="M7 16v-3"/><path d="M11 16V8"/><path d="M15 16v-5"/><path d="m19 8-4-4-4 4-4-4"/>',
    sliders:'<path d="M4 21v-7"/><path d="M4 10V3"/><path d="M12 21v-9"/><path d="M12 8V3"/><path d="M20 21v-5"/><path d="M20 12V3"/><path d="M1 14h6"/><path d="M9 8h6"/><path d="M17 16h6"/>',
    settings:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.74v.5a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    back:'<path d="M14.8 5.5 8.3 12l6.5 6.5"/>',
    more:'<circle cx="5" cy="12" r="1.35" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.35" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.35" fill="currentColor" stroke="none"/>',
    clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.2V12l3.2 2"/>',
    plus:'<path d="M5 12h14"/><path d="M12 5v14"/>',
    check:'<path d="M20 6 9 17l-5-5"/>',
    close:'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    chevrons:'<path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>',
    play:'<path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"/>',
    pause:'<rect x="14" y="3" width="5" height="18" rx="1"/><rect x="5" y="3" width="5" height="18" rx="1"/>',
    disc3:'<circle cx="12" cy="12" r="10"/><path d="M6 12c0-1.7.7-3.2 1.8-4.2"/><circle cx="12" cy="12" r="2"/><path d="M18 12c0 1.7-.7 3.2-1.8 4.2"/>'
  };
  const stroke={plus:'var(--plus-stroke,2.5)',check:'var(--check-stroke,3)',close:'var(--close-stroke,2)',chevrons:'var(--chevrons-stroke,1.75)'};
  const sw=stroke[name]??'var(--icon-stroke,2)';
  return `<svg class="sf-icon" viewBox="0 0 24 24" aria-hidden="true" style="stroke-width:${sw}">${icons[name]||''}</svg>`;
}


function timerStateIcon(s,rt){
  const active=isTimerActive(rt),paused=isTimerPaused(s,rt);
  const name=active?'disc3':paused?'pause':'play';
  const spin=active&&data.settings.animateActiveTimerIcon?' spin':'';
  return `<span class="icon timer-state-icon${spin}" aria-hidden="true">${svgIcon(name)}</span>`;
}
function durationParts(ms){return fmtDuration(ms).split(':');}
function fmtDurationWithColons(ms,blink=false){
  return durationParts(ms).map((part,index)=>`<span data-total-part="${index}">${esc(part)}</span>`).join(`<span class="colon${blink?' blink':''}">:</span>`);
}
function refreshTimerReadouts(){
  const s=data.current;
  if(ui.tab!=='timers'||ui.timerView!=='timers'||!s)return;
  document.querySelectorAll('[data-timer]').forEach(card=>{
    const rt=s.timers.find(t=>t.id===card.dataset.timer);
    const el=card.querySelector('.time');
    if(rt&&el)el.textContent=fmtDuration(timerDuration(rt));
  });
  const totalEl=document.querySelector('.total-time');
  if(totalEl){
    const parts=durationParts(sessionTotal(s));
    const nodes=[...totalEl.querySelectorAll('[data-total-part]')];
    if(nodes.length===parts.length)nodes.forEach((node,index)=>node.textContent=parts[index]);
    else totalEl.innerHTML=fmtDurationWithColons(sessionTotal(s),s.timers.some(isTimerActive)&&data.settings.blinkTotalColon);
  }
}

function shell(content,tab=ui.tab){
  const tabs=[['timers','timers','Cronômetros'],['history','history','Histórico'],['stats','stats','Estatísticas'],['settings','settings','Ajustes']];
  return `<div class="app-shell">${content}</div><nav class="tabbar ${UI_CONFIG.tabbar?.showLabels===false?'hide-labels':''}" aria-label="Navegação principal">
    ${tabs.map(([id,ic,l])=>`<button data-tab="${id}" class="${tab===id?'active':''}" aria-label="${l}">${svgIcon(ic)}<span class="tab-label">${l}</span></button>`).join('')}
  </nav>${data.undo&&data.undo.expiresAt>now()?`<div class="undo"><span>Alteração realizada</span><button id="undoBtn">Desfazer</button></div>`:''}`;
}

function renderTimers(){
  const s=data.current, models=activeModels();
  if(ui.timerView==='models') return renderModelsPage();
  if(!models.length){ return shell(`<header class="topbar simple"><h1>Cronômetro</h1></header><main class="content"><div class="empty">Nenhum modelo criado.<br><br><button class="ios-button" id="createFirst">Criar modelo</button></div></main>`); }
  if(!s) return '';
  const model=modelById(s.modelId);
  const timerMode=currentTimerMode();
  const central=timerMode.layout==='central';
  const cards=s.timers.sort((a,b)=>a.order-b.order).map(rt=>`<button class="timer-card ${central?'central':''} ${timerStateClass(s,rt)}" data-timer="${rt.id}" aria-label="${esc(rt.name)}, ${fmtDuration(timerDuration(rt))}">
      ${timerStateIcon(s,rt)}
      <span class="name">${esc(rt.name)}${rt.isAdhoc?'<span class="badge">Etapa avulsa</span>':''}</span>
      <span class="time">${fmtDuration(timerDuration(rt))}</span>
    </button>`).join('');
  const running=s.timers.some(isTimerActive);
  const blink=running&&data.settings.blinkTotalColon;
  const titlePopover=ui.popover?.type==='title'?`<div class="popover-backdrop" id="closePopover"></div><div class="title-popover floating-window"><button id="titleRename">Renomear</button><button id="titleEditModel">Editar modelo</button><button id="titleDiscard" class="danger">Zerar e descartar</button></div>`:'';
  return shell(`<header class="topbar timer-topbar"><div class="header-row"><button class="circle-button" id="modelsBack" aria-label="Modelos">${svgIcon('back')}</button><button class="current-title ${s.manualTitle?'':'untitled'}" id="currentTitleButton">${esc(currentTitle())}</button><button class="circle-button" id="sessionMenu" aria-label="Detalhes">${svgIcon('more')}</button>${titlePopover}</div><div class="current-model-name">${esc(model?.name||s.modelNameSnapshot)}</div>${s.customized?'<div class="status-line">Personalizado neste registro</div>':''}</header>
  <main class="content timer-content"><div class="timer-list">${cards}<button class="add-card" id="addAdhoc">${svgIcon('plus')}<span>Adicionar cronômetro</span></button></div></main>
  <div class="floating-actions timer-actions"><section class="total-card floating-card ${running?'running':''}"><span class="total-icon">${svgIcon('clock')}</span><span class="total-copy"><small>Tempo total</small><strong class="total-time">${fmtDurationWithColons(sessionTotal(s),blink)}</strong></span></section><button class="save-btn" id="saveBtn">${svgIcon('check')}<span>Salvar</span></button></div>`);
}

function renderHistory(){
  const sessions=data.sessions.filter(s=>s.status==='saved'&&!s.deletedAt).sort((a,b)=>(b.restoredAt||b.savedAt)-(a.restoredAt||a.savedAt));
  const filtered=sessions.filter(s=>{
    const q=ui.historyQuery.trim().toLocaleLowerCase(); if(q&&!s.title.toLocaleLowerCase().includes(q))return false;
    if(ui.historyModel!=='all'&&s.modelId!==ui.historyModel)return false;
    if(ui.historyDate&&dayKey(s.restoredAt||s.savedAt)!==ui.historyDate)return false; return true;
  });
  const groups={};filtered.forEach(s=>{const k=dayKey(s.restoredAt||s.savedAt);(groups[k]??=[]).push(s);});
  const list=Object.entries(groups).map(([k,arr])=>`<div class="history-day">${fmtDate(new Date(k+'T12:00:00').getTime())}</div>${arr.map(s=>`<button class="history-card" data-session="${s.id}"><div class="top"><strong>${esc(s.title)}</strong><span>${s.isNoMeasurement?'':fmtDuration(sessionTotal(s,s.savedAt))}</span></div>${s.isNoMeasurement?'<span class="badge">Sem medição</span>':''}${s.restoredAt?'<span class="badge">Restaurado</span>':''}</button>`).join('')}`).join('');
  return shell(`<header class="topbar"><h1>Registros</h1></header><main class="content history-content"><div class="filters"><input id="historySearch" placeholder="Buscar título" value="${esc(ui.historyQuery)}"><select id="historyModel"><option value="all">Todos os modelos</option>${activeModels().map(m=>`<option value="${m.id}" ${ui.historyModel===m.id?'selected':''}>${esc(m.name)}</option>`).join('')}</select><div class="date-filter"><input id="historyDate" type="date" value="${esc(ui.historyDate)}">${ui.historyDate?`<button id="historyDateClear" aria-label="Limpar data">${svgIcon('close')}</button>`:''}</div><button class="chip history-trash" id="historyTrash">Apagados recentemente</button></div>${list||'<div class="empty">Nenhum registro encontrado.</div>'}</main>`);
}

function validMeasuredSessions(){ return data.sessions.filter(s=>s.status==='saved'&&!s.deletedAt&&!s.isNoMeasurement && !!modelById(s.modelId)); }
function renderStats(){
  const ss=validMeasuredSessions(); const count=ss.length,total=ss.reduce((a,s)=>a+sessionTotal(s,s.savedAt),0),avg=count?total/count:0;
  const byTimer=new Map();
  ss.forEach(s=>s.timers.forEach(t=>{const d=timerDuration(t,s.savedAt);if(d<=0)return;const key=t.templateId||`adhoc:${t.name}`;const x=byTimer.get(key)||{name:t.name,vals:[],total:0};x.vals.push(d);x.total+=d;byTimer.set(key,x);}));
  const timers=[...byTimer.values()].sort((a,b)=>b.total-a.total); const maxTotal=Math.max(1,...timers.map(x=>x.total));
  let trend='Sem dados suficientes'; if(ss.length>=2){const ordered=[...ss].sort((a,b)=>a.originalRecordedAt-b.originalRecordedAt);const half=Math.max(1,Math.floor(ordered.length/2));const a=ordered.slice(0,half).reduce((x,s)=>x+sessionTotal(s,s.savedAt),0)/half;const bArr=ordered.slice(-half);const b=bArr.reduce((x,s)=>x+sessionTotal(s,s.savedAt),0)/bArr.length;const pct=a?((b-a)/a*100):0;trend=pct<0?`${Math.abs(pct).toFixed(1).replace('.',',')}% mais rápido`:`${pct.toFixed(1).replace('.',',')}% mais lento`;}
  const timerRows=(kind)=>timers.map(x=>{let value;if(kind==='avg')value=x.total/x.vals.length;if(kind==='best')value=Math.min(...x.vals);if(kind==='worst')value=Math.max(...x.vals);return `<div class="row"><span>${esc(x.name)}</span><strong>${fmtDuration(value)}</strong></div>`}).join('')||'<div class="muted">Sem dados.</div>';
  const percentRows=timers.map(x=>`<div><div class="row"><span>${esc(x.name)}</span><strong>${total?(x.total/total*100).toFixed(1).replace('.',','):0}%</strong></div><div class="bar"><span style="width:${Math.min(100,x.total/maxTotal*100)}%"></span></div></div>`).join('')||'<div class="muted">Sem dados.</div>';
  return shell(`<header class="topbar"><h1>Estatísticas</h1></header><main class="content"><h2 class="section-title">Visão geral</h2>${count?`<div class="stats-grid">
    <section class="panel"><h3>Resumo</h3><div class="row"><span>Registros medidos</span><strong>${count}</strong></div><div class="row"><span>Tempo acumulado</span><strong>${fmtDuration(total)}</strong></div><div class="row"><span>Média por registro</span><strong>${fmtDuration(avg)}</strong></div></section>
    <section class="panel"><h3>Tempo total por registro</h3>${ss.sort((a,b)=>b.originalRecordedAt-a.originalRecordedAt).slice(0,12).map(s=>`<div class="row"><span>${esc(s.title)}</span><strong>${fmtDuration(sessionTotal(s,s.savedAt))}</strong></div>`).join('')}</section>
    <section class="panel"><h3>Tempo de cada cronômetro</h3>${timers.map(x=>`<div><div class="row"><span>${esc(x.name)}</span><strong>${fmtDuration(x.total)}</strong></div><div class="bar"><span style="width:${x.total/maxTotal*100}%"></span></div></div>`).join('')}</section>
    <section class="panel"><h3>Média por cronômetro</h3>${timerRows('avg')}</section>
    <section class="panel"><h3>Melhor tempo</h3>${timerRows('best')}</section>
    <section class="panel"><h3>Pior tempo</h3>${timerRows('worst')}</section>
    <section class="panel"><h3>Percentual no tempo total</h3>${percentRows}</section>
    <section class="panel"><h3>Evolução / tendência</h3><div class="stat-big">${esc(trend)}</div><p class="muted small">Comparação da média da primeira metade dos registros com a metade mais recente.</p></section>
  </div>`:`<div class="empty">As estatísticas aparecerão depois que você salvar registros com medição.</div>`}</main>`);
}


function renderSettings(){
  const presets=UI_CONFIG.themePresets||[];
  const speeds=Object.values(UI_CONFIG.animationSpeeds||{});
  const customSelected=data.settings.colorTheme==='custom';
  const speedRow=data.settings.animateActiveTimerIcon?`<div class="settings-row animation-speed-row"><div class="animation-speed-options" role="group" aria-label="Velocidade da animação">${speeds.map(sp=>`<button data-animation-speed="${esc(sp.id)}" class="${data.settings.activeTimerAnimationSpeed===sp.id?'selected':''}" aria-pressed="${data.settings.activeTimerAnimationSpeed===sp.id?'true':'false'}">${esc(sp.name)}</button>`).join('')}</div></div>`:'';

  return shell(`<header class="topbar simple"><h1>Ajustes</h1></header><main class="settings-content">
    <section class="settings-section"><div class="settings-card">
      <label class="settings-row" for="themeSelect"><span>Aparência</span><span class="select-wrap"><select id="themeSelect"><option value="system" ${data.settings.theme==='system'?'selected':''}>Sistema</option><option value="light" ${data.settings.theme==='light'?'selected':''}>Claro</option><option value="dark" ${data.settings.theme==='dark'?'selected':''}>Escuro</option></select><span class="chevrons">${svgIcon('chevrons')}</span></span></label>
      <label class="settings-row" for="timerSizeSelect"><span>Tamanho do cronômetro</span><span class="select-wrap"><select id="timerSizeSelect"><option value="small" ${data.settings.timerSize==='small'?'selected':''}>Pequeno</option><option value="large" ${data.settings.timerSize==='large'?'selected':''}>Grande</option></select><span class="chevrons">${svgIcon('chevrons')}</span></span></label>
      <button class="settings-row button-row" id="toggleVersionBadge" aria-pressed="${data.settings.showVersionBadge?'true':'false'}"><span>Mostrar versão no topo</span><span class="ios-switch ${data.settings.showVersionBadge?'on':''}" aria-hidden="true"></span></button>
      <button class="settings-row button-row" id="toggleTotalColonBlink" aria-pressed="${data.settings.blinkTotalColon?'true':'false'}"><span>Piscar os dois pontos do tempo total</span><span class="ios-switch ${data.settings.blinkTotalColon?'on':''}" aria-hidden="true"></span></button>
    </div></section>

    <section class="settings-section"><div class="settings-card animation-settings-card">
      <button class="settings-row button-row" id="toggleActiveTimerAnimation" aria-pressed="${data.settings.animateActiveTimerIcon?'true':'false'}"><span>Animar ícone do cronômetro ativo</span><span class="ios-switch ${data.settings.animateActiveTimerIcon?'on':''}" aria-hidden="true"></span></button>
      ${speedRow}
    </div></section>

    <section class="settings-section"><h3 class="section-label">Tema</h3><div class="settings-card color-card"><div class="theme-presets">${presets.map(p=>`<button class="theme-preset ${data.settings.colorTheme===p.id?'selected':''}" data-color-theme="${esc(p.id)}"><span class="theme-dot" style="--theme-accent:${esc(p.accent)};--theme-action:${esc(p.action)}"></span><span>${esc(p.name)}</span></button>`).join('')}<button class="theme-preset ${customSelected?'selected':''}" data-color-theme="custom"><span class="theme-dot custom-dot" style="--theme-accent:${esc(data.settings.accentColor||'#007AFF')};--theme-action:${esc(data.settings.accentColor||'#007AFF')}"></span><span>Personalizada</span></button></div>${customSelected?`<div class="custom-theme-row"><input id="accentCustom" type="color" value="${esc(data.settings.accentColor||'#007AFF')}"><span>${esc((data.settings.accentColor||'#007AFF').toUpperCase())}</span></div>`:''}</div></section>

    <section class="settings-section"><h3 class="section-label">Backup</h3><div class="settings-card"><button class="settings-row button-row accent-button-row" id="exportJson"><span>Fazer backup</span></button></div><p class="section-footer">Salve o arquivo JSON em uma pasta que você não se esqueça</p></section>

    <section class="settings-section"><div class="settings-card"><label class="settings-row button-row" for="importJsonFile"><span>Restaurar Backup</span><input id="importJsonFile" class="sr-only" type="file" accept="application/json,.json"></label></div><p class="section-footer">Restaura um backup substituindo os dados atuais pelos dados do arquivo JSON escolhido.</p></section>

    <section class="settings-section"><h3 class="section-label">Dados e exportação</h3><div class="settings-card"><button class="settings-row button-row" id="exportCsv"><span>Exportar CSV para planilhas</span></button><button class="settings-row button-row" id="exportPdf"><span>Exportar relatório PDF</span></button></div></section>

    <section class="settings-section"><h3 class="section-label">Armazenamento</h3><div class="settings-card"><div class="settings-row"><span>Dados salvos em</span><span class="secondary-value">Neste aparelho</span></div><div class="settings-row"><span>iCloud</span><span class="secondary-value">Apenas se salvo manualmente</span></div></div><p class="section-footer">Os registros são salvos em cache no seu navegador, caso o cache seja limpo, os dados serão perdidos.</p></section>

    <section class="settings-section"><div class="settings-card"><div class="settings-row"><span>Versão</span><span class="secondary-value">${esc(APP_META.version)}</span></div></div></section>
  </main>`);
}

function renderModelsPage(){
  const all=activeModels();
  return shell(`<header class="topbar simple models-header"><h1>Modelos</h1><button class="text-button models-edit-button" id="toggleModelsEdit">${ui.modelsEditing?'Concluir':'Editar'}</button></header><main class="content models-page"><button class="create-model-card" id="createModel">${svgIcon('plus')}<span>Criar novo modelo</span></button><div class="models-list">${all.map((m,i)=>`<div class="model-list-item"><button class="model-main" data-choose-model="${m.id}"><strong>${esc(m.name)}</strong><span>${m.timers.filter(t=>!t.removedAt).length} cronômetro(s)</span></button>${ui.modelsEditing?`<div class="model-reorder"><button data-move-model="${m.id}" data-dir="-1" ${i===0?'disabled':''}>↑</button><button data-move-model="${m.id}" data-dir="1" ${i===all.length-1?'disabled':''}>↓</button></div>`:`<button class="circle-button small-circle" data-model-options="${m.id}" aria-label="Opções de ${esc(m.name)}">${svgIcon('more')}</button>`}${ui.popover?.type==='modelOptions'&&ui.popover.id===m.id?`<div class="popover-backdrop" id="closePopover"></div><div class="model-popover floating-window"><button data-model-rename="${m.id}">Renomear</button><button data-model-edit="${m.id}">Editar</button><button data-model-dup="${m.id}">Duplicar</button><button data-model-delete="${m.id}" class="danger">Apagar</button></div>`:''}</div>`).join('')}</div></main>`,'timers');
}
function renderEditModel(m){ const ts=m.timers.filter(t=>!t.removedAt).sort((a,b)=>a.order-b.order);return `<div class="modal-wrap"><section class="sheet"><div class="sheet-head"><h2>${esc(m.name)}</h2><button class="chip" id="closeToModels">Concluir</button></div><div class="toolbar"><button id="renameModel">Renomear modelo</button><button id="addTemplate">＋ Cronômetro</button></div>${ts.length?ts.map((t,i)=>`<div class="panel"><div class="row"><span><strong>${esc(t.name)}</strong></span><span class="toolbar"><button data-move-template="${t.id}" data-dir="-1" ${i===0?'disabled':''}>↑</button><button data-move-template="${t.id}" data-dir="1" ${i===ts.length-1?'disabled':''}>↓</button></span></div><div class="toolbar"><button data-edit-template="${t.id}">Editar</button><button data-remove-template="${t.id}" class="danger">Remover</button></div></div>`).join(''):'<div class="empty">Este modelo está vazio. Você pode mantê-lo assim ou adicionar cronômetros.</div>'}</section></div>`; }
function renderSessionMenu(){ const s=data.current;return `<div class="modal-wrap"><section class="sheet details-sheet" role="dialog" aria-modal="true"><div class="sheet-head liquid-head"><button class="circle-button glass" id="closeModal" aria-label="Fechar">${svgIcon('close')}</button><h2>Detalhes</h2><span class="sheet-spacer"></span></div><div class="sheet-body"><section class="sheet-card"><textarea id="currentNote" class="notes-box" rows="5" placeholder="Notas">${esc(s.note)}</textarea></section><section class="sheet-card"><button class="sheet-row action-row" id="menuCustomize">Organizar cronômetros</button></section></div></section></div>`; }

function renderOrganize(){const s=data.current;return `<div class="modal-wrap"><section class="sheet"><div class="sheet-head"><h2>Organizar registro</h2><button class="chip" id="closeModal">Concluir</button></div>${s.timers.sort((a,b)=>a.order-b.order).map((t,i)=>`<div class="panel"><div class="row"><strong>${esc(t.name)}</strong><span class="toolbar"><button data-move-current="${t.id}" data-dir="-1" ${i===0?'disabled':''}>↑</button><button data-move-current="${t.id}" data-dir="1" ${i===s.timers.length-1?'disabled':''}>↓</button></span></div><div class="toolbar"><button data-rename-current="${t.id}">Renomear</button><button data-remove-current="${t.id}" class="danger">Remover</button></div></div>`).join('')}</section></div>`;}
function renderSessionDetail(s){ const model=modelById(s.modelId);return `<div class="modal-wrap"><section class="sheet"><div class="sheet-head"><h2>${esc(s.title)}</h2><button class="chip" id="closeModal">Fechar</button></div><div class="toolbar"><button data-edit-session-title="${s.id}">Editar título</button>${!model?' <button data-rebuild-model="'+s.id+'">Criar modelo deste registro</button>':''}<button data-delete-session="${s.id}" class="danger">Excluir</button></div><section class="panel"><div class="row"><span>Modelo de origem</span><strong>${esc(model ? (model.deletedAt ? 'Modelo excluído' : model.name) : 'Modelo excluído')}</strong></div>${s.isNoMeasurement?'<div class="row"><span class="badge">Sem medição</span></div>':`<div class="row"><span>Tempo total</span><strong>${fmtDuration(sessionTotal(s,s.savedAt))}</strong></div><div class="row"><span>Tempo decorrido</span><strong>${fmtDuration(sessionElapsedNet(s,s.savedAt))}</strong></div><div class="row"><span>Pausas</span><strong>${fmtDuration(pauseTotal(s,s.savedAt))}</strong></div>`}<div class="row"><span>Registrado originalmente em</span><span>${fmtDateTime(s.originalRecordedAt)}</span></div>${s.restoredAt?`<div class="row"><span>Restaurado em</span><span>${fmtDateTime(s.restoredAt)}</span></div>`:''}</section>
    ${!s.isNoMeasurement?s.timers.filter(t=>timerDuration(t,s.savedAt)>0).sort((a,b)=>a.order-b.order).map(t=>`<section class="panel"><div class="row"><span><strong>${esc(t.name)}</strong>${t.isAdhoc?'<br><span class="badge">Etapa avulsa</span>':''}${t.isRemoved?'<br><span class="badge">Removido do modelo</span>':''}</span><strong>${fmtDuration(timerDuration(t,s.savedAt))}</strong></div><details><summary class="muted small">Horários e intervalos</summary>${t.intervals.map(i=>`<div class="row small"><span>${fmtDateTime(i.startedAt)}</span><span>${i.endedAt?fmtDateTime(i.endedAt):'aberto'}</span></div>`).join('')}</details><button class="action" data-correct-time="${s.id}" data-timer-id="${t.id}">Corrigir tempo</button></section>`).join(''):''}
    <section class="panel"><label for="detailNote"><strong>Nota</strong></label><textarea id="detailNote" rows="4" data-note-session="${s.id}" placeholder="Notas">${esc(s.note)}</textarea><div id="noteStatus" class="muted small"></div></section></section></div>`; }
function renderTrash(){ const deletedSessions=data.sessions.filter(s=>s.deletedAt),deletedModels=data.models.filter(m=>m.deletedAt);return `<div class="modal-wrap"><section class="sheet"><div class="sheet-head"><h2>Apagados recentemente</h2><button class="chip" id="closeModal">Fechar</button></div><h3>Registros</h3>${deletedSessions.map(s=>`<div class="panel"><strong>${esc(s.title)}</strong><div class="toolbar"><button data-restore-session="${s.id}">Restaurar</button><button data-hard-session="${s.id}" class="danger">Apagar definitivamente</button></div></div>`).join('')||'<p class="muted">Nenhum registro.</p>'}<h3>Modelos</h3>${deletedModels.map(m=>`<div class="panel"><strong>${esc(m.name)}</strong><div class="toolbar"><button data-restore-model="${m.id}">Restaurar</button><button data-hard-model="${m.id}" class="danger">Apagar definitivamente</button></div></div>`).join('')||'<p class="muted">Nenhum modelo.</p>'}</section></div>`; }



function render(){
  applyTheme();

  if(ui.tab==='timers')$app.innerHTML=renderTimers();
  if(ui.tab==='history')$app.innerHTML=renderHistory();
  if(ui.tab==='stats')$app.innerHTML=renderStats();
  if(ui.tab==='settings')$app.innerHTML=renderSettings();

  if(ui.modal){
    if(ui.modal.type==='editModel'){const m=modelById(ui.modal.id);if(m)$app.insertAdjacentHTML('beforeend',renderEditModel(m));}
    if(ui.modal.type==='sessionMenu')$app.insertAdjacentHTML('beforeend',renderSessionMenu());
    if(ui.modal.type==='organize')$app.insertAdjacentHTML('beforeend',renderOrganize());
    if(ui.modal.type==='session'){const s=data.sessions.find(x=>x.id===ui.modal.id);if(s)$app.insertAdjacentHTML('beforeend',renderSessionDetail(s));}
    if(ui.modal.type==='trash')$app.insertAdjacentHTML('beforeend',renderTrash());
  }

  document.getElementById('app-version-badge')?.remove();
  if(data.settings.showVersionBadge){
    document.body.insertAdjacentHTML('beforeend',`<div id="app-version-badge" class="app-version-badge">v${esc(APP_META.version)}</div>`);
  }

  bind();
}
