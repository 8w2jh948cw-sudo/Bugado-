'use strict';

const $app = document.getElementById('app');
const $toast = document.getElementById('toast');

let db;
let ui = {
  tab:'timers',
  timerView:'timers',
  modal:null,
  popover:null,
  modelsEditing:false,
  historyQuery:'',
  historyModel:'all',
  historyDate:''
};

let data = {
  models:[],
  sessions:[],
  current:null,
  settings:{
    theme:'system',
    colorTheme:'original',
    timerSize:'small',
    simultaneous:'single',
    accentColor:'#007AFF',
    showVersionBadge:false,
    animateActiveTimerIcon:true,
    activeTimerAnimationSpeed:'normal',
    blinkTotalColon:true,
    statsCards:['summary','total','timers','average','best','worst','percent','trend']
  },
  undo:null
};

let tickHandle=null;
let toastHandle=null;

const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
const now = () => Date.now();
const clone = obj => JSON.parse(JSON.stringify(obj));
const esc = v => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const pad = n => String(n).padStart(2,'0');
const fmtDateTime = ms => { const d=new Date(ms); return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} • ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const fmtDate = ms => { const d=new Date(ms); return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()}`; };
const dayKey = ms => { const d=new Date(ms); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; };
const fmtDuration = ms => { ms=Math.max(0,Math.round(ms/1000)*1000); const s=Math.floor(ms/1000), h=Math.floor(s/3600), m=Math.floor((s%3600)/60), sec=s%60; return h?`${h}:${pad(m)}:${pad(sec)}`:`${pad(m)}:${pad(sec)}`; };
const fmtShort = ms => { const s=Math.round(ms/1000); if(s<60)return `${s}s`; const m=Math.round(s/60); if(m<60)return `${m} min`; return `${(m/60).toFixed(1).replace('.',',')} h`; };

function defaultModel(){
  const t=now();
  return {id:uid(),name:'Meu modelo',createdAt:t,updatedAt:t,deletedAt:null,sortOrder:0,timers:[]};
}

function recordedFromTemplate(t){
  return {id:uid(),templateId:t.id,name:t.name,order:t.order,isAdhoc:false,isRemoved:false,intervals:[],correctedDurationMs:null};
}

function newSession(model){
  const t=now();
  return {
    id:uid(),modelId:model.id,modelNameSnapshot:model.name,title:'',manualTitle:false,note:'',
    openedAt:t,firstTimerStartedAt:null,savedAt:null,originalRecordedAt:null,restoredAt:null,
    deletedAt:null,status:'active',isNoMeasurement:false,globalPaused:false,pauseIntervals:[],
    pausedActiveTimerIds:[],customized:false,
    timers:model.timers.filter(x=>!x.removedAt).sort((a,b)=>a.order-b.order).map(recordedFromTemplate)
  };
}

function modelById(id){ return data.models.find(m=>m.id===id); }
function activeModels(){ return data.models.filter(m=>!m.deletedAt).sort((a,b)=>(a.sortOrder??0)-(b.sortOrder??0)||a.createdAt-b.createdAt); }
function nextModelOrder(){ return Math.max(-1,...data.models.map(m=>Number.isFinite(m.sortOrder)?m.sortOrder:-1))+1; }

function timerDuration(rt,at=now()){
  if(rt.correctedDurationMs!=null)return rt.correctedDurationMs;
  return rt.intervals.reduce((sum,i)=>sum+Math.max(0,(i.endedAt??at)-i.startedAt),0);
}
function sessionTotal(s,at=now()){ return s.timers.reduce((a,t)=>a+timerDuration(t,at),0); }
function pauseTotal(s,at=now()){ return s.pauseIntervals.reduce((a,p)=>a+Math.max(0,(p.endedAt??at)-p.startedAt),0); }
function sessionElapsedGross(s,at=now()){ const start=s.firstTimerStartedAt??s.openedAt; const end=s.savedAt??at; return Math.max(0,end-start); }
function sessionElapsedNet(s,at=now()){ return Math.max(0,sessionElapsedGross(s,at)-pauseTotal(s,at)); }
function openInterval(rt){ return [...rt.intervals].reverse().find(i=>i.endedAt==null); }
function isTimerActive(rt){ return !!openInterval(rt); }
function openPause(s){ return [...(s.pauseIntervals||[])].reverse().find(p=>p.endedAt==null); }
function isTimerPaused(s,rt){ return !isTimerActive(rt)&&timerDuration(rt)>0; }
function isTimerDone(){ return false; }

function startPause(s,t){
  if(!s.firstTimerStartedAt||s.timers.some(isTimerActive)||openPause(s))return;
  s.pauseIntervals||=[];
  s.pauseIntervals.push({id:uid(),startedAt:t,endedAt:null,origin:'no-active-timer'});
}
function endPause(s,t){ const p=openPause(s); if(p)p.endedAt=t; }

function haptic(kind='light'){
  try{if(navigator.vibrate)navigator.vibrate(kind==='save'?[20,25,20]:kind==='switch'?[12,18,12]:kind==='undo'?[8,12,8]:10);}catch(_){}
}
function toast(msg){
  clearTimeout(toastHandle);
  $toast.textContent=msg;
  $toast.classList.add('show');
  toastHandle=setTimeout(()=>$toast.classList.remove('show'),1800);
}
function setUndo(snapshot,label='Troca desfeita'){
  data.undo={snapshot,expiresAt:now()+5000,label};
  render();
  setTimeout(()=>{if(data.undo&&data.undo.expiresAt<=now()){data.undo=null;render();}},5100);
}
async function undo(){
  if(!data.undo)return;
  data.current=data.undo.snapshot;
  data.undo=null;
  await persistCurrent();
  haptic('undo');
  toast('Desfeito');
  render();
}
