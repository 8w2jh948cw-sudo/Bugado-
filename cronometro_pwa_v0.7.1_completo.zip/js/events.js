'use strict';

function bind(){
  document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{ui.tab=b.dataset.tab;ui.modal=null;ui.popover=null;if(ui.tab==='timers')ui.timerView='timers';render();});
  const byId=id=>document.getElementById(id);
  if(byId('createFirst'))byId('createFirst').onclick=createModel;
  if(byId('modelsBack'))byId('modelsBack').onclick=()=>{ui.timerView='models';ui.modal=null;ui.popover=null;render();};
  if(byId('currentTitleButton'))byId('currentTitleButton').onclick=()=>{ui.popover={type:'title'};render();};
  if(byId('sessionMenu'))byId('sessionMenu').onclick=()=>{ui.modal={type:'sessionMenu'};ui.popover=null;render();};
  document.querySelectorAll('[data-timer]').forEach(b=>b.onclick=()=>tapTimer(b.dataset.timer));
  if(byId('addAdhoc'))byId('addAdhoc').onclick=addAdhoc;
  if(byId('saveBtn'))byId('saveBtn').onclick=saveSession;
  if(byId('undoBtn'))byId('undoBtn').onclick=undo;
  if(byId('closeModal'))byId('closeModal').onclick=()=>{ui.modal=null;render();};
  if(byId('closePopover'))byId('closePopover').onclick=()=>{ui.popover=null;render();};
  document.querySelectorAll('.modal-wrap').forEach(w=>w.onclick=e=>{if(e.target===w){ui.modal=null;render();}});
  if(byId('closeToModels'))byId('closeToModels').onclick=()=>{ui.modal=null;render();};
  if(byId('createModel'))byId('createModel').onclick=createModel;
  if(byId('toggleModelsEdit'))byId('toggleModelsEdit').onclick=()=>{ui.modelsEditing=!ui.modelsEditing;ui.popover=null;render();};
  document.querySelectorAll('[data-model-options]').forEach(b=>b.onclick=e=>{e.stopPropagation();ui.popover={type:'modelOptions',id:b.dataset.modelOptions};render();});
  document.querySelectorAll('[data-model-rename]').forEach(b=>b.onclick=()=>{ui.popover=null;renameModel(modelById(b.dataset.modelRename));});
  document.querySelectorAll('[data-model-edit]').forEach(b=>b.onclick=()=>{ui.popover=null;ui.modal={type:'editModel',id:b.dataset.modelEdit};render();});
  document.querySelectorAll('[data-model-dup]').forEach(b=>b.onclick=()=>{ui.popover=null;duplicateModel(modelById(b.dataset.modelDup));});
  document.querySelectorAll('[data-model-delete]').forEach(b=>b.onclick=()=>{ui.popover=null;deleteModel(modelById(b.dataset.modelDelete));});
  document.querySelectorAll('[data-move-model]').forEach(b=>b.onclick=()=>moveModel(b.dataset.moveModel,Number(b.dataset.dir)));
  document.querySelectorAll('[data-choose-model]').forEach(b=>b.onclick=()=>chooseModel(b.dataset.chooseModel));
  document.querySelectorAll('[data-edit-model]').forEach(b=>b.onclick=()=>{ui.modal={type:'editModel',id:b.dataset.editModel};render();});
  document.querySelectorAll('[data-dup-model]').forEach(b=>b.onclick=()=>duplicateModel(modelById(b.dataset.dupModel)));
  document.querySelectorAll('[data-delete-model]').forEach(b=>b.onclick=()=>deleteModel(modelById(b.dataset.deleteModel)));
  if(ui.modal?.type==='editModel'){
    const m=modelById(ui.modal.id);
    if(byId('renameModel'))byId('renameModel').onclick=()=>renameModel(m); if(byId('addTemplate'))byId('addTemplate').onclick=()=>addTemplate(m);
    document.querySelectorAll('[data-edit-template]').forEach(b=>b.onclick=()=>editTemplate(m,b.dataset.editTemplate));
    document.querySelectorAll('[data-remove-template]').forEach(b=>b.onclick=()=>removeTemplate(m,b.dataset.removeTemplate));
    document.querySelectorAll('[data-move-template]').forEach(b=>b.onclick=()=>moveTemplate(m,b.dataset.moveTemplate,Number(b.dataset.dir)));
  }
  if(byId('titleRename'))byId('titleRename').onclick=async()=>{const current=data.current;const initial=current.manualTitle?current.title:'';const n=(prompt('Título:',initial)||'').trim();if(n){current.title=n;current.manualTitle=true;await persistCurrent();}ui.popover=null;render();};
  if(byId('titleEditModel'))byId('titleEditModel').onclick=()=>{const m=modelById(data.current?.modelId);ui.popover=null;if(m)ui.modal={type:'editModel',id:m.id};render();};
  if(byId('titleDiscard'))byId('titleDiscard').onclick=async()=>{ui.popover=null;await discardCurrent();};
  const currentNote=byId('currentNote');if(currentNote){let tm;currentNote.oninput=e=>{data.current.note=e.target.value;clearTimeout(tm);tm=setTimeout(()=>persistCurrent(),180);};currentNote.onblur=()=>persistCurrent();}
  if(byId('menuCustomize'))byId('menuCustomize').onclick=()=>{ui.modal={type:'organize'};render();};
  document.querySelectorAll('[data-move-current]').forEach(b=>b.onclick=()=>moveCurrentTimer(b.dataset.moveCurrent,Number(b.dataset.dir)));
  document.querySelectorAll('[data-rename-current]').forEach(b=>b.onclick=()=>renameCurrentTimer(b.dataset.renameCurrent));
  document.querySelectorAll('[data-remove-current]').forEach(b=>b.onclick=()=>removeCurrentTimer(b.dataset.removeCurrent));
  if(byId('historySearch'))byId('historySearch').oninput=e=>{ui.historyQuery=e.target.value;render();};
  if(byId('historyModel'))byId('historyModel').onchange=e=>{ui.historyModel=e.target.value;render();};
  if(byId('historyDate'))byId('historyDate').onchange=e=>{ui.historyDate=e.target.value;render();};
  if(byId('historyDateClear'))byId('historyDateClear').onclick=()=>{ui.historyDate='';render();};
  if(byId('historyTrash'))byId('historyTrash').onclick=()=>{ui.modal={type:'trash'};render();};
  document.querySelectorAll('[data-session]').forEach(b=>b.onclick=()=>{ui.modal={type:'session',id:b.dataset.session};render();});
  document.querySelectorAll('[data-delete-session]').forEach(b=>b.onclick=()=>deleteSession(data.sessions.find(s=>s.id===b.dataset.deleteSession)));
  document.querySelectorAll('[data-edit-session-title]').forEach(b=>b.onclick=()=>editSessionTitle(data.sessions.find(s=>s.id===b.dataset.editSessionTitle)));
  document.querySelectorAll('[data-rebuild-model]').forEach(b=>b.onclick=()=>rebuildModelFromSession(data.sessions.find(s=>s.id===b.dataset.rebuildModel)));
  document.querySelectorAll('[data-correct-time]').forEach(b=>b.onclick=()=>{const s=data.sessions.find(s=>s.id===b.dataset.correctTime);const t=s?.timers.find(t=>t.id===b.dataset.timerId);if(s&&t)correctTimer(s,t);});
  const note=byId('detailNote'); if(note){let tm;note.oninput=e=>{clearTimeout(tm);tm=setTimeout(()=>saveSessionNote(e.target.dataset.noteSession,e.target.value),350);};}
  document.querySelectorAll('[data-restore-session]').forEach(b=>b.onclick=()=>restoreSession(data.sessions.find(s=>s.id===b.dataset.restoreSession)));
  document.querySelectorAll('[data-hard-session]').forEach(b=>b.onclick=()=>hardDeleteSession(data.sessions.find(s=>s.id===b.dataset.hardSession)));
  document.querySelectorAll('[data-restore-model]').forEach(b=>b.onclick=()=>restoreModel(modelById(b.dataset.restoreModel)));
  document.querySelectorAll('[data-hard-model]').forEach(b=>b.onclick=()=>hardDeleteModel(modelById(b.dataset.hardModel)));
  if(byId('themeSelect'))byId('themeSelect').onchange=async e=>{data.settings.theme=e.target.value;await persistSettings();render();};
  if(byId('timerSizeSelect'))byId('timerSizeSelect').onchange=async e=>{data.settings.timerSize=e.target.value;await persistSettings();render();};
  if(byId('exportCsv'))byId('exportCsv').onclick=exportCSV;
  if(byId('exportJson'))byId('exportJson').onclick=exportJSON;
  if(byId('exportPdf'))byId('exportPdf').onclick=exportPDF;
  document.querySelectorAll('[data-color-theme]').forEach(b=>b.onclick=async()=>{data.settings.colorTheme=b.dataset.colorTheme;if(data.settings.colorTheme==='custom'&&!data.settings.accentColor)data.settings.accentColor='#007AFF';await persistSettings();render();});
  if(byId('accentCustom'))byId('accentCustom').onchange=async e=>{data.settings.accentColor=e.target.value;data.settings.colorTheme='custom';await persistSettings();render();};
  if(byId('importJsonFile'))byId('importJsonFile').onchange=async e=>{const f=e.target.files?.[0];if(f)await importJSON(f);e.target.value='';};
  if(byId('toggleVersionBadge'))byId('toggleVersionBadge').onclick=async()=>{
    data.settings.showVersionBadge=!data.settings.showVersionBadge;
    await persistSettings();
    render();
  };
  if(byId('toggleActiveTimerAnimation'))byId('toggleActiveTimerAnimation').onclick=async()=>{
    data.settings.animateActiveTimerIcon=!data.settings.animateActiveTimerIcon;
    await persistSettings();
    render();
  };
  document.querySelectorAll('[data-animation-speed]').forEach(b=>b.onclick=async()=>{
    data.settings.activeTimerAnimationSpeed=b.dataset.animationSpeed;
    await persistSettings();
    render();
  });
  if(byId('toggleTotalColonBlink'))byId('toggleTotalColonBlink').onclick=async()=>{
    data.settings.blinkTotalColon=!data.settings.blinkTotalColon;
    await persistSettings();
    render();
  };
}
