'use strict';

const DB_NAME='cronometro_local_v1';
const DB_VERSION=1;
const FACTORY_SEED_STATE_KEY='factorySeedVersion';

function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{
      const d=req.result;
      if(!d.objectStoreNames.contains('models'))d.createObjectStore('models',{keyPath:'id'});
      if(!d.objectStoreNames.contains('sessions'))d.createObjectStore('sessions',{keyPath:'id'});
      if(!d.objectStoreNames.contains('state'))d.createObjectStore('state',{keyPath:'key'});
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}

function tx(store,mode='readonly'){return db.transaction(store,mode).objectStore(store);}
function getAll(store){return new Promise((res,rej)=>{const r=tx(store).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
function getState(key){return new Promise((res,rej)=>{const r=tx('state').get(key);r.onsuccess=()=>res(r.result?.value);r.onerror=()=>rej(r.error);});}
function put(store,value){return new Promise((res,rej)=>{const r=tx(store,'readwrite').put(value);r.onsuccess=()=>res(value);r.onerror=()=>rej(r.error);});}
function del(store,key){return new Promise((res,rej)=>{const r=tx(store,'readwrite').delete(key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
function putState(key,value){return put('state',{key,value});}

async function persistCurrent(){await putState('current',data.current);}
async function persistSettings(){await putState('settings',data.settings);}

async function loadFactoryData(){
  const response=await fetch('./data/initial-data.json',{cache:'no-store'});
  if(!response.ok)throw new Error('Não foi possível carregar os dados iniciais.');
  const payload=await response.json();
  if(!payload||!Array.isArray(payload.models))throw new Error('Arquivo de dados iniciais inválido.');
  return payload;
}

async function seedFactoryDataIfNeeded(){
  const marker=await getState(FACTORY_SEED_STATE_KEY);
  if(marker!=null)return;

  const [existingModels,existingSessions,existingState]=await Promise.all([
    getAll('models'),
    getAll('sessions'),
    getAll('state')
  ]);

  // Só instala os dados de fábrica quando o banco está realmente vazio.
  // Isso também protege quem já usava o app e decidiu apagar todos os modelos.
  const hasPreviousInstallation=
    existingModels.length>0 ||
    existingSessions.length>0 ||
    existingState.some(item=>item.key!==FACTORY_SEED_STATE_KEY);

  if(hasPreviousInstallation){
    await putState(FACTORY_SEED_STATE_KEY,APP_META.factoryDataVersion);
    return;
  }

  const payload=await loadFactoryData();

  await new Promise((resolve,reject)=>{
    const tr=db.transaction(['models','state'],'readwrite');
    const models=tr.objectStore('models');
    const state=tr.objectStore('state');

    payload.models.forEach((model,index)=>{
      models.put({...clone(model),sortOrder:Number.isFinite(model.sortOrder)?model.sortOrder:index});
    });
    state.put({key:FACTORY_SEED_STATE_KEY,value:APP_META.factoryDataVersion});

    tr.oncomplete=resolve;
    tr.onerror=()=>reject(tr.error);
    tr.onabort=()=>reject(tr.error||new Error('Inicialização de dados cancelada.'));
  });
}

async function purgeExpired(){
  const cutoff=now()-30*24*60*60*1000;
  for(const s of [...data.sessions]){
    if(s.deletedAt&&s.deletedAt<cutoff){
      await del('sessions',s.id);
      data.sessions=data.sessions.filter(x=>x.id!==s.id);
    }
  }
  for(const m of [...data.models]){
    if(m.deletedAt&&m.deletedAt<cutoff){
      await del('models',m.id);
      data.models=data.models.filter(x=>x.id!==m.id);
    }
  }
}
